from django.urls import path
from . import views

urlpatterns = [

    path('', views.home_view, name='home'),
    path('signup/', views.signup, name='signup'),
    path('signin/', views.signin_view, name='signin'),
    path('feedback/', views.feedback_view, name='feedback'),
   path('admin-login/', views.admin_dashboard, name='admin-login'),  # your admin login page
    path('logout/', views.admin_logout, name='admin-logout'),  # custom logout
    path('admin-dashboard/', views.admin_dashboard, name='admin-dashboard'),
  
 
    
]
