from django import forms
from django.contrib.auth.models import User
from .models import Feedback




class SignInForm(forms.Form):
    username = forms.CharField(
        max_length=100,
        label="Username",
        widget=forms.TextInput(attrs={
            "placeholder": "Enter your username",
            "class": "form-control"
        })
    )
    password = forms.CharField(
        label="Password",
        widget=forms.PasswordInput(attrs={
            "placeholder": "Enter your password",
            "class": "form-control"
        })
    )


class FeedbackForm(forms.ModelForm):
    rating = forms.IntegerField(
        label="Rating (1-5)",
        widget=forms.NumberInput(attrs={
            "class": "form-control",
            "placeholder": "Rate between 1 and 5",
            "min": 1,
            "max": 5
        }),
        help_text="Provide a rating from 1 (lowest) to 5 (highest)."
    )
    comment = forms.CharField(
        label="Comment",
        widget=forms.Textarea(attrs={
            "class": "form-control",
            "placeholder": "Write your feedback here...",
            "rows": 4
        }),
        help_text="Add detailed feedback if possible."
    )

    class Meta:
        model = Feedback
        fields = ['rating', 'comment']
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')
