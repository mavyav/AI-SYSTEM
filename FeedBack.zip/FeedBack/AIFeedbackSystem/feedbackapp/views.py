from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import SignUpForm, SignInForm, FeedbackForm
from .models import Feedback
from django.contrib.auth.models import User
from django.contrib import messages
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import logout
from .models import Feedback
import joblib
import os

# Load sentiment analysis model
MODEL_PATH = os.path.join(os.path.dirname(__file__), '../model_training/sentiment_model.pkl')
VECTORIZER_PATH = os.path.join(os.path.dirname(__file__), '../model_training/vectorizer.pkl')

model = joblib.load(MODEL_PATH)
vectorizer = joblib.load(VECTORIZER_PATH)



def admin_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        if username == "admin" and password == "admin123":
            request.session['admin_logged_in'] = True
            return redirect('admin-dashboard')
        else:
            messages.error(request, "Invalid admin credentials")
    return render(request, 'admin_login.html')

def admin_dashboard(request):
    if not request.session.get('admin_logged_in'):
        return redirect('admin-login')

    feedbacks = Feedback.objects.all()
    positive = feedbacks.filter(sentiment='Positive').count()
    negative = feedbacks.filter(sentiment='Negative').count()
    neutral = feedbacks.filter(sentiment='Neutral').count()
    total = feedbacks.count()

    return render(request, 'admin_dashboard.html', {
        'feedbacks': feedbacks,
        'positive': positive,
        'negative': negative,
        'neutral': neutral,
        'total': total
    })




def signin_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(username=username, password=password)

        if user:
            login(request, user)
            return redirect("feedback")
        else:
            messages.error(request, "Invalid credentials")

    return render(request, "signin.html")



def signup_view(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Account created successfully! Please log in.")
            return redirect('signin')
    else:
        form = SignUpForm()

    return render(request, "signup.html", {"form": form})


def signup(request):
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists")
            return redirect('signup')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already exists")
            return redirect('signup')

        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()

        messages.success(request, "Account created successfully")
        return redirect('signin')

    return render(request, "signup.html")


# Sign In
def signin_view(request):
    if request.method == 'POST':
        form = SignInForm(request.POST)
        if form.is_valid():
            user = authenticate(
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password']
            )
            if user:
                login(request, user)
                return redirect('feedback')
            else:
                messages.error(request, "Invalid credentials")
    else:
        form = SignInForm()

    return render(request, 'signin.html', {'form': form})


# Feedback
@login_required
def feedback_view(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            feedback.user = request.user

            # Sentiment analysis
            text = feedback.comment
            text_vector = vectorizer.transform([text])
            sentiment = model.predict(text_vector)[0]

            feedback.sentiment = sentiment
            feedback.save()

            messages.success(request, f"Feedback submitted! Sentiment: {sentiment}")
            return redirect('feedback')
    else:
        form = FeedbackForm()

    all_feedback = Feedback.objects.filter(user=request.user)

    return render(request, 'feedback.html', {
        'form': form,
        'feedbacks': all_feedback
    })




def admin_login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        if username == "admin" and password == "admin123":
            return redirect('admin-dashboard')
        else:
            messages.error(request, "Invalid admin credentials")

    return render(request, "admin_login.html")


def admin_dashboard_view(request):
    feedbacks = Feedback.objects.all()

    positive = feedbacks.filter(sentiment="Positive").count()
    negative = feedbacks.filter(sentiment="Negative").count()
    neutral = feedbacks.filter(sentiment="Neutral").count()
    total = feedbacks.count()

    return render(request, "admin_dashboard.html", {
        "feedbacks": feedbacks,
        "positive": positive,
        "negative": negative,
        "neutral": neutral,
        "total": total
    })


# --- Admin Login & Dashboard ---
def admin_dashboard(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Static admin credentials
        if username == "admin" and password == "admin123":
            request.session['admin_logged_in'] = True

            feedbacks = Feedback.objects.all()
            positive = feedbacks.filter(sentiment='Positive').count()
            negative = feedbacks.filter(sentiment='Negative').count()
            neutral = feedbacks.filter(sentiment='Neutral').count()
            total = feedbacks.count()

            return render(request, 'admin_dashboard.html', {
                'feedbacks': feedbacks,
                'positive': positive,
                'negative': negative,
                'neutral': neutral,
                'total': total
            })
        else:
            messages.error(request, "Invalid admin credentials")

    return render(request, 'admin_login.html')



@login_required
def admin_logout(request):
    logout(request)
    return redirect('home')



def home_view(request):
    return render(request, 'home.html')


# Logout
def logout_view(request):
    logout(request)
    return redirect('home')
